<?php
header("Content-Type: application/vnd.apple.mpegurl");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Expose-Headers: Content-Length,Content-Range");
header("Access-Control-Allow-Headers: Range");
header("Accept-Ranges: bytes");
function HttpCall($url, $data, $headers, $method, $return) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_PROXY, $proxy);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, $return);
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
  $output = curl_exec ($ch);
  return $output;
}

include 'index.php';

$a1=HttpCall($url1,"",$headers1,"GET",0);

//echo $a1;
$a1= str_replace("http://live12p.akt.hotstar-cdn.net/hls/live/2003704/incaallow-indvssl2023/hin/1540020913/15mindvrm019c30f271b01942498af5fae10d856c4607january2023/","https://github.com/priyankjivani123/test2/raw/main/",$a1);

echo $a1;