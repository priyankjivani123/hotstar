<?php

$HTTP_X_REQUESTED_WITH=$_SERVER['HTTP_X_REQUESTED_WITH'];

if($HTTP_X_REQUESTED_WITH=='star.sports79'){
echo "successssss";

}else{
 
 
 
 echo "you are not authorised";



}
?>