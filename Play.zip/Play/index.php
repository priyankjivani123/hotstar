<?php
$file = file_get_contents("cookie.txt");
$json = json_decode($file, 1);
$cookie = $json['cookie']["cookie"];

$url1="http://18.66.53.45/hls/live/2024729/inallow-asiacup-2023/hin/1540024254/15mindvrm0143c5e5d05c4f4d1fa3d652031492525a03september2023/master_apmf_480_4.m3u8?random=3-inallow-asiacup-2023&content_id=1540024254&language=hindi&resolution=854x480&hash=4c69&bandwidth=393800&media_codec=h265&audio_codec=aac&layer=child&playback_proto=http&playback_host=live12p-pristine-akt.cdn.hotstar.com&si_match_id=708502";
$tsUrl="http://108.159.80.16/hls/live/2024729/inallow-asiacup-2023/hin/1540024254/15mindvrm0143c5e5d05c4f4d1fa3d652031492525a03september2023/";
$headers1[]='Cookie: '.$cookie.'';
$headers1[]='User-Agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36';

 $headers1[]='Host: live-ssai-cf-mum-ace.cdn.hotstar.com';
 
    //   $headers1[]='origin: https://www.hotstar.com';


    //          $headers1[]='referer: https://www.hotstar.com/';

?>