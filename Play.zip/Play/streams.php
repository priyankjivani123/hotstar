<?php
header("Content-Type: application/vnd.apple.mpegurl");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Expose-Headers: Content-Length,Content-Range");
header("Access-Control-Allow-Headers: Range");
header("Accept-Ranges: bytes");
include 'index.php';
if (@$_REQUEST["ts"] != "")
{
     $opts = ["http" => ["method" => "GET", "header" => $headers1]];
    $context = stream_context_create($opts);   
    $haystack = file_get_contents($tsUrl."master".$_REQUEST["ts"], false, $context);  
    echo $haystack;
  }
?>