<?php
$file = file_get_contents("cookie.txt");
$json = json_decode($file, 1);
$cookie = $json['cookie']["cookie"];

$url1="https://live12p.hotstar.com/hls/live/2024725/inallow-asiacup-2023/hin/1540024257/15mindvrm01648533429bd54a4da3859a1d84f86f8a04september2023/master_apmf_480_4.m3u8";
$tsUrl="https://live12p.hotstar.com/hls/live/2024725/inallow-asiacup-2023/hin/1540024257/15mindvrm01648533429bd54a4da3859a1d84f86f8a04september2023/";

         $headers1=array('Cookie: hdntl=exp=1693907226~acl=%2fhls%2flive%2f2024725%2finallow-asiacup-2023%2fhin%2f1540024257%2f15mindvrm01648533429bd54a4da3859a1d84f86f8a04september2023%2fmaster_apmf*~id=aaee4c02b9cd0a531362f880b97cb364~data=ip%3dkVHSwsuqddqIoL59u0Ftu7o2RnVDpfiQs-userid%3dbnNztLfzJ125YQI5xrGFnPmxXyepVxU3plMYeKk0SSCe-did%3dSdVbRDgHnma7B2ORuLKU6zP4ogfhDfewIVWSJIVunWLz9C2qkoWweEJ-cc%3din-~hmac=960d7c24d4880bed08460ee69a900beb42a0131e14ea09728a31d2e47aeb593b','User-Agent: Hotstar;in.startv.hotstar/23.08.11.4.8914 (Android/13)','Host: live12p.hotstar.com','Accept-Encoding: identity','Connection: Keep-Alive');
         
         
         
         
    
     
       
        
         
          
          
          
          /*
            $headers1[]='Cookie: '.$cookie.'';
  $headers1[]='Host: live12p.hotstar.com';
   $headers1[]='User-Agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36';

    
     
       
       
       
                 
                 
                 
                 */

 
 
    //   $headers1[]='origin: https://www.hotstar.com';


    //          $headers1[]='referer: https://www.hotstar.com/';

?>