<!DOCTYPE html>
<html>
<head>
<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  background-color: #2196F3;
  padding: 10px;
}

.grid-item {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.8);
  padding: 20px;
  font-size: 30px;
  text-align: center;
}
</style>
</head>
<body>
<?php 
function HttpCall($url, $data, $headers, $method, $return) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_PROXY, $proxy);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, $return);
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
  $output = curl_exec ($ch);
  return $output;
}
if($_REQUEST['slug']){
function decode($data){
$key = "YJ7JbNtEJPdcofDi";
$iv = "cofDiv4tsOiZ3/tT"; 
$decoded = openssl_decrypt(base64_decode($data), 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv); 
return $decoded; 
}
$url="https://rtslivee7.tk/newapi/get_channel.php?slug=".$_REQUEST['slug'];
$data='';
$headers=array('Host: rtsliiv4.tk','accept-encoding: gzip','user-agent: okhttp/4.10.0');
$output=httpcall($url,$data,$headers,"GET",0);
$json= decode($output);

$obj = array(json_decode($json,true));
    foreach($obj as $obj)
    {
    ?>
 <div class="grid-container">
<div class="grid-item">  
<?php
     echo $obj['link'];
     $related= $obj['related'];
     foreach($related as $related)
     {
        $channelTitle= $related['title'];
        $channelImage= $related['image'];
        $channelmSlug= $related['slug'];
         ?>
	

<form width ="100%" align="center">
<a href="?slug=<?php echo $channelmSlug ?>"><img src="<?php echo $channelImage; ?>" height="50%" width="50%"><br><b><?php echo $channelTitle ?></b></a> 
</form>




         <?php
     } 
    
    }
}else{
 echo "check url";
 
 }

//   echo $json['related'];
// $json=json_decode($json);
//  echo $json;

 //print_r($json);
//  echo $json[0];
//  echo json_decode[$json]['link'];

?>
</div>  

</div>
</body>
</html>


<?php



/*
$key=base64_decode('YJ7JbNtEJPdcofDi');


$datatohash="o20etm+kBMTiVuXC+KAUp/GfsEgCiqVtwqtQlhpYIhNhZfcsA/ZuthVBYQoCSz6e2DAlx0zet1A63ML56IQGqHFTUys2LleBjE6LdvEVwFCxMvbeO52Ulw5DioO4t6RpAVtElLObOjZ783NSM5+kW2/h9nHPmeTKCejUbnomSESSHGgFWarxQgRQCyg/h8wFU7cjvHbPAjyl/Rp7D2F9yPmpFYxkRZbYaDe4GAqVUPVOXqpIsUPV2x03YFe4SIgPzsouPfZXEtMH/hGyvQvh0540jhjtpRB+wNjAhORDevcqqlF4t4eEdjVhRaMfondPFSIxg7nyDgvTnoXkzZnkgzTugw74TgIkELaHPYjDn8GYfLo/HRoxe+qHXJlg/IbT+XihocTtqrnmytHA1bwbnmeTKWppmqiuVTiW4Ruu5p4Ra23H+gyHUR1dqfntmI21nhIF0oquFNpR0jDFx4nA/L0tRifT4sMrdjoGO6DmBsbRxiXGodE8VqxTLoVb6rdIUjCvPY6cx5wnjSe0QmvbAj/3DM0nYfDkoyrhHGknqs1h9EOUuXCEjcu/MjiHEFWngToQVNydcU1r0ZKlbVUdYtNef8dxEN1w4PlIRzczQMAwqAMTvDpsv9y+v4lRZRN6u0aaowNdmEimT7aR1789Cbg8fWHBRjic8wOBzequO+YODYSj7kz5pYB2CNojI0bQqVV+G+LH17s0nQi7CWO5BSSNO5Fg+1Vtpqvs7lkKBF311BNx2blVsx30JRStAXJ0EPV9aikioK9oX1/xxGAZ++9VwF1uLeCgVkSIaAytHrPTUMAmsP8bmIP191AMz3DwZG4YFuUM8t99DknVnx4NUjllcmHyrrXkzhpO/9LeY/KNj2xmIUIWHHYguZKwmAz2ioX7lyv8oQL91PLAdc6Jun/0FbeGW8lHHsA4mB4UIPhs7HeBSAX9w6dW3okj2AC0VVFjFFZyS1Htt3TCJRjUDk6L47PkeuWMDWnX5CyxgGFhminrISo2eLjMTPC/eMadvIaDe55aHNoPKi97/y42n5uiIbapZC1T2AJN2XLNGu6lCL98daOXLzVfCnjcTRSISzd2IsATvZrlsAmV9UnscxwR+npZFbmugBEBGqB5uvBNLOBsVO27ZJRAEKSmp6HDxkOLLUIqzkn6kWkZxGHWNxI9DMTipe8Y18yBM/hOkC5Gj6On3ieWFBk7OAWuWDizaxaYBpkF8/VX5AGXgjoiluDUI8/PrfSibbloyQN+B5sbfacewWRjGCStSpxy6+BceS2AKD+KFQ3iOe2qZwWKkQTjZoJl4nxA1qpvGKk9NFPDHEsjkbKZ9192wtwCrFTq5LYubUxbAXhWPEotEjGu1N8q6MYkbQa1FZR1QCsi44cu8zRO5KGYIhYqZ61WSD8zTby1WT7BHpWl18rIN6ea4QH6h1sUJmx0sFbyoV6MNOhfCOAUWKfmyRWVrBMTeSRLqXowseO+UNF3ZgGPc8uLa/9TfHu4LG2v2jzrSKLS9fAYNiJCyRkZ8RoxiwSZ21rnfi8Autqs7efGfplpdADIKIEbv2nYtceQzTSUkKljlrsAaSjQRE/Qb4sPlOiu3I7ccSsq+dC1MrtasTsmXHtH4ggep2fWPBozyY96pugvPDxdNXQqP4vXvgo1PTM8jPMB4di23z8NMtKcw3TNvMeXE4FUWr74wo6zJ7EvA9jGWyFbJi5ukJq72/hb0UoeNwSdlxyjwPFmnLaMPfTEmSVrfQyEc0gMe6jH1yAp5Vzf8g0kyxzwkBWCG0LbsgKZwL84+8O06RUdbSgbwfGGFdd5Sy0yXhfcNtoDSIEb4vsC75UHtpWIzHrM+x3eFnlTJ5/zGFQuCqxYFCmJk/ZL35Tf08E3C8odmnvgeDpZChVXtGLlhAL18R6L5GUttYhuqD9e+LQon2YzRMnWSgapq1taouNyWWBxXnNRXMzwM6uio66EERWUpHUavtPieG1ofYF6PdXMNgUz5VvwC+hRRyKsdemsXRVUZpp2sFA0hcxrE1CKRepF9/dGyYfrZfCUOlLRhXgS+uTpum4ThhMx6F/eOz8V7lVMvGmvgj8ad4AMmY7SCNGzblMvFTW1WjOKFaxKs7yT9uRzcmUcV4nZPsHR1F/vYxVmZoF/qRGxZWcgKFNZrnaQ5VaHEeNj71VAktu+QJKA15pkYQnjJgoxmFZ/PCdXf5MwxT2C542ZioMxqSJoySRbcltZbEW8760jLnu9OBp658IDcLQ00DTq+mL+6s/+cF4ffrTRd3LxOD5xKA99r0V5Pskk6ocV5NOzFIbRb52mowxGCEgNBgn6dW2vU0ybEf1IVWsEPd0ZtQWl2v7HT56T19vWeyTqOUJVD4e0zrUOHAMoAKOM//qkmxYDWta4IsB2wiNzhZlJ7VjPbito1N44NZe119i9q2Bzszo1XqOte8h9PZuXFQZ0WGH48rEnyBZZI8lOKp5dSmF5fegG4yLoWRFMjH7aOQ2nPPSIYgf3zLJkopPEzlnojwlLlSyA3jT74DrO+3ea3mIhvfUHpCjIBP1ngm/hQ/fkv1CnpD5hAKrYhszOciml1TvUjFspP52WLBSk+1js71O9ruIwO/eh5or10R97Je/UQbkqCCRplzewmOacA3QMTEgZwTcERjREdk/NoWyG7yyvDo+7VPZ2Qah73yBfmDT3Y8744pBPGPPEoDNgd76ix1xrkoSAvfeQuJaBE4U6igTH9yH+Rr/cJkTifh+4Pja21xq1y09k9S6xVy2xbsuJj8A7X7nRFWCjvly30LBvbczzQ11TMNx450g6mjOWeZd2svvPci9YkF3vyKTZu3nkVmorDzlkM5W7VSjW7+xCdhRoetTWhqY0GLx88aoQnhebM3lCQVEvF8jMdWnpVSd3i/wAseQC1BEIC97ZHtmXNyZCUa/2/Do6a1UxgGt6NcjGRWjV/1MeQm4G6zg8HLcOfZ0dKyvKnBfgdMKv8Oea53zukAIteF+GEdo5eOOoRL/EcmJJsTMzFyCpWBJygZ/RrtcSnXvr7FuyPkWVZ9PAUX3mYUo=";

$hash=hash_hmac('YJ7JbNtEJPdcofDi', $datatohash,$key);

echo $hash;
*/
?>