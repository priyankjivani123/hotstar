<?php

$headers1=array('Host: delta4tatasky.akamaized.net','Connection: keep-alive','User-Agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Mobile Safari/537.36','Accept: */*','Origin: https://m.live4wap.xyz','Sec-Fetch-Site: cross-site','Sec-Fetch-Mode: cors','Sec-Fetch-Dest: empty','Referer: https://m.live4wap.xyz/embed.php','Accept-Encoding: gzip, deflate, br','Accept-Language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,hi;q=0.6');

function HttpCall($url, $data, $headers, $method, $return) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_PROXY, $proxy);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, $return);
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
  $output = curl_exec ($ch);
  return $output;
}
   
    $url1="https://delta4tatasky.akamaized.net/out/i/6527249_7_9729212.ts?m=1667707338";

  $a1=HttpCall($url1,"",$headers1,"GET",0);

   print $a1;
?>