<?php
$cookie=$_GET['cookie'];

$data_file='cookie.txt';

$current_data = file_get_contents($data_file);

$array_data = json_decode($current_data, 1); 

$printdata=array("cookie"=>"$cookie");
	
$array_data['cookie'] = $printdata; 

$final_data = json_encode($array_data, JSON_PRETTY_PRINT);

file_put_contents($data_file, $final_data);

//To get cookie value
$file = file_get_contents("http://noobbro.xyz/Hotstar/cookie.txt");
$json = json_decode($file, 1);
$cookie = $json['cookie']["cookie"];

echo $cookie;

?>