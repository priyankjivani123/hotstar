<?php
header("Content-Type: application/vnd.apple.mpegurl");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Expose-Headers: Content-Length,Content-Range");
header("Access-Control-Allow-Headers: Range");
header("Accept-Ranges: bytes");
function HttpCall($url, $data, $headers, $method, $return) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_PROXY, $proxy);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, $return);
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
  $output = curl_exec ($ch);
  return $output;
}

include 'index.php';
     $headers1[]='Host: live12p-pristine-akt.cdn.hotstar.com';

$a1=HttpCall($url1,"",$headers1,"GET",0);

 $a1= str_replace("/hls/live/2024729/inallow-asiacup-2023/hin/1540024257/15mindvrm01648533429bd54a4da3859a1d84f86f8a04september2023/","noob.php?ts=",$a1);

   
if (@$_REQUEST["ts"] != "")
{

         
         
         
           array_pop($headers1);
  $headers1[]='Host: live-ssai-gme-mum.cdn.hotstar.com';

 
     $opts = ["http" => ["method" => "GET", "header" => $headers1]];
    $context = stream_context_create($opts);   

    $haystack = file_get_contents($tsUrl.$_REQUEST["ts"], false, $context);
    
    
      
          echo HttpCall($tsUrl.$_REQUEST["ts"],'', $headers1,"GET", 0);
          
          
          
          
    echo $haystack;
    
    
    
           
    
    /*
        $file_git = file_get_contents($tsUrl.$_REQUEST["ts"], false, $context);
$data_git = array(
'sha'=>file_get_contents("sha.txt"),
'message'=>'image',
'content'=> base64_encode($file_git),
'committer'=> array(
'name'=>'Test',
'email' => 'test@test.teshjhx'
)
);
$data_string_git = json_encode($data_git);
$ch_git = curl_init('https://api.github.com/repos/priyankjivani123/test2/contents/'.$_REQUEST["ts"]);
curl_setopt($ch_git, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch_git, CURLOPT_POSTFIELDS, $data_string_git);
curl_setopt($ch_git, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch_git, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 YaBrowser/19.9.3.314 Yowser/2.5 Safari/537.36',
'Authorization: token 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'
));
$result_git = curl_exec($ch_git);
//echo $result_git;
$p_git = json_decode($result_git);
file_put_contents("sha.txt",$p_git->content->sha);


*/

    
         }
            else{
            
            echo $a1;
            }
?>