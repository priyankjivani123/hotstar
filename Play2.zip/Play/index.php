<?php
$file = file_get_contents("cookie.txt");
$json = json_decode($file, 1);
$cookie = $json['cookie']["cookie"];

$url1="http://live12p-pristine-akt.cdn.hotstar.com/hls/live/2024729/inallow-asiacup-2023/hin/1540024257/15mindvrm01648533429bd54a4da3859a1d84f86f8a04september2023/master_apmf_480_4.m3u8?random=3-inallow-asiacup-2023&content_id=1540024257&language=hindi&resolution=854x480&hash=4c69&bandwidth=393800&media_codec=h265&audio_codec=aac&layer=child&playback_proto=http&playback_host=live12p-pristine-akt.cdn.hotstar.com&si_match_id=708503";
$tsUrl="http://live-ssai-gme-mum.cdn.hotstar.com/hls/live/2024729/inallow-asiacup-2023/hin/1540024257/15mindvrm01648533429bd54a4da3859a1d84f86f8a04september2023/";
$headers1[]='Cookie: '.$cookie.'';
$headers1[]='User-Agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36';

    
     
      

 
 
    //   $headers1[]='origin: https://www.hotstar.com';


    //          $headers1[]='referer: https://www.hotstar.com/';

?>