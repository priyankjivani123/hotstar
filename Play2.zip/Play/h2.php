<?php

function HttpCall($url, $data, $headers, $method, $return) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_PROXY, $proxy);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, $return);
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
  $output = curl_exec ($ch);
  return $output;
}

$url="https://api.hotstar.com/play/v4/playback/content/1260110227?desired-config=ads%3Assai%7Caudio_channel%3Astereo%7Caudio_codec%3Aaac%7Ccontainer%3Ats%7Cdvr%3Ashort%7Cencryption%3Aplain%7Cladder%3Aphone%7Clanguage%3Ahin%7Cpackage%3Ahls%7Csubs-tag%3AHotstarVIP%7Cvideo_codec%3Ah264&device-id=9361714916A48688222BDB9DF9305E9167A0AD26&os-name=android&os-version=11";
$data='{"app_version":"12.4.7","platform_version":"12.4.7","app_name":"android","platform":"android","device_model":"DN2101","device_manufacturer":"OnePlus","language":"hin","download":false,"os_name":"android","os_version":"11","client_capabilities":{"packages":["dash","hls"],"container":["fmp4","fmp4br","ts"],"ads":["ssai","non_ssai"],"audio_channel":["stereo"],"encryption":["plain"],"video_codec":["h264","h265","vp9"],"ladder":["phone"],"resolution":["sd","hd","fhd"],"dynamic_range":["sdr","hdr10"]},"drm_parameters":{"widevine_security_level":["HW_SECURE_DECODE","HW_SECURE_ALL"],"hdcp_version":["HDCP_NO_DIGITAL_OUTPUT"]},"resolution":"Auto"}';

$key=base64_decode('BfwaAcrJS8QS/FMSB3X57g==');

$time=time();
$t=$time+600;
$datatohash='st='.$time.'~exp='.$t.'~acl=/*';

$hash=hash_hmac('sha256', $datatohash,$key);

$headers=array('hotstarauth: '.$datatohash.'~hmac='.$hash.'','X-Country-Code: in','X-HS-Request-Id: e808b6be-dfd9-4032-9197-ce0a1cc1b7b8','X-HS-AppVersion: 12.4.7','X-HS-Platform: android','Accept-Language: eng','X-HS-UserToken: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJ1bV9hY2Nlc3MiLCJleHAiOjE2NjY4NzIxNjUsImlhdCI6MTY2Njc4NTc2NSwiaXNzIjoiVFMiLCJqdGkiOiIzZWYwMmRkZjM2NjU0NmQ0YjBmNjA4NTNhNTkzOWJkNyIsInN1YiI6IntcImhJZFwiOlwiYWNkODhkZjAwOGM1NDczMmE0Njg4MTVkMjRmMjVjZDVcIixcInBJZFwiOlwiMjQ0OGQ0ZDZjMTRlNGU4MDgxMjY0ZWViYjI4MjRkN2ZcIixcIm5hbWVcIjpcInJ1dHZpa1wiLFwicGhvbmVcIjpcIjgxNTU4MTIzODhcIixcImlwXCI6XCI0OS4zNC4yNTAuMTg4XCIsXCJjb3VudHJ5Q29kZVwiOlwiaW5cIixcImN1c3RvbWVyVHlwZVwiOlwibnVcIixcInR5cGVcIjpcInBob25lXCIsXCJpc0VtYWlsVmVyaWZpZWRcIjpmYWxzZSxcImlzUGhvbmVWZXJpZmllZFwiOnRydWUsXCJkZXZpY2VJZFwiOlwiNTUzZWRkYmMtZjc3Mi00OGMzLTg3ZTYtMDNkYTYxZmRlMWM1XCIsXCJwcm9maWxlXCI6XCJBRFVMVFwiLFwidmVyc2lvblwiOlwidjJcIixcInN1YnNjcmlwdGlvbnNcIjp7XCJpblwiOntcIkhvdHN0YXJNb2JpbGVcIjp7XCJzdGF0dXNcIjpcIlNcIixcImV4cGlyeVwiOlwiMjAyMy0wMS0yM1QwNzoyMjo0NC4wMDBaXCIsXCJzaG93QWRzXCI6XCIxXCIsXCJjbnRcIjpcIjFcIn19fSxcImVudFwiOlwiQ2cwU0N3Z0JPQUZBQVZEUUJWZ0JDamNLQlFvRENnRUZFaTRTQjJGdVpISnZhV1FTQTJsdmN4SUhhbWx2TFd4NVpob0NjMlFhQW1oa0lnTnpaSElxQm5OMFpYSmxiMWdCQ2lJS0dnb09FZ1UxTlRnek5oSUZOalF3TkRrS0NDSUdabWx5WlhSMkVnUTRaRmdCQ3BvQkNnVUtBd29CQUJLUUFSSUhZVzVrY205cFpCSURhVzl6RWdkcWFXOHRiSGxtRWdsaGJtUnliMmxrZEhZU0JtWnBjbVYwZGhJSFlYQndiR1YwZGhJRWNtOXJkUklEZDJWaUVnUnRkMlZpRWdkMGFYcGxiblIyRWdWM1pXSnZjeElHYW1sdmMzUmlFZ3BqYUhKdmJXVmpZWE4wRWdSMGRtOXpFZ1J3WTNSMkVnTnFhVzhhQW5Oa0dnSm9aQ0lEYzJSeUtnWnpkR1Z5Wlc5WUFSSUpDQUVRb0l1STdOMHdcIixcImlzc3VlZEF0XCI6MTY2Njc4NTc2NTU2N30iLCJ2ZXJzaW9uIjoiMV8wIn0.a79mWA2FXUUPR-QZqheWjgeg-rOBYJNioXGchQgpHb0','User-Agent: Hotstar;in.startv.hotstar/12.4.7.1168 (Android/11)','Content-Type: application/json; charset=UTF-8','Content-Length: '.strlen($data).'','Host: api.hotstar.com','Connection: Keep-Alive','Accept-Encoding: gzip');
$a1=HttpCall($url,$data,$headers,"POST",0);
echo $a1;
$json=json_decode($a1,true);

    foreach($json['data']['playback_sets'] as $hey){
            //echo $hey['playback_url']."<br>";
            if(str_contains($hey['playback_url'],'english') && str_contains($hey['playback_url'],'h264')){
               $link=$hey['playback_url'];
               echo $link;
               
            }
    }
    $link='';;
 print_r($link);
  if($link){
  //echo "2828";
  $url="$link";
  $data='';
  $headers=array('Host: tailor.akt.hotstar-cdn.net','Connection: keep-alive','Upgrade-Insecure-Requests: 1','User-Agent: Mozilla/5.0 (Linux; Android 11; DN2101) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36','Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','Accept-Encoding: gzip, deflate','Accept-Language: en-IN,en-US;q=0.9,en-GB;q=0.8,en;q=0.7',);
  $cookie1=HttpCall($url,$data,$headers,"GET",1);
  //echo $cookie1;
    $cookie1=trim(explode('Access-Control-Allow-Origin:',explode('Set-Cookie:',$cookie1)[1])[0]);
    $cookie1= explode('; path=/', $cookie1);
    $cookie=$cookie1["0"];
    
    if($cookie){
        $url="http://tailor-cwp.akt.hotstar-cdn.net/hls-1-icct20wc2022/1540019011/english/h264/320x180-f0ea/180400/child.m3u8?playback_proto=http&playback_host=live11p.akt.hotstar-cdn.net&playback_path=L2hscy9saXZlLzIwMDM2OTMvaWNjdDIwd2MyMDIyL2VuZy8xNTQwMDE5MDExLzE1bWluZHZybTAyNjU4ZTFmZThkN2E4NDExNGFjMDY2ZTJiZjQ1YWNjMGYyN29jdG9iZXIyMDIyL21hc3Rlcl8xLm0zdTg=&si_match_id=706902&audio_codec=aac";
        $data='';
        $headers=array('Cookie: '.$cookie.'','User-Agent: Mozilla/5.0 (Linux; Android 11; DN2101) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36','Host: tailor-cwp.akt.hotstar-cdn.net','Connection: Keep-Alive','Accept-Encoding: gzip');
        $ts=HttpCall($url,$data,$headers,"GET",0);
        $a=array("cookie"=>"$cookie","ts"=>"$ts");
        //str_replace("","",$a);
        echo json_encode($a);
    }
  }
    die;
  
  $m=trim(explode('X-Akamai-Live-Origin-QoS:',explode('Set-Cookie:',$a1)[1])[0]);
  echo $m;
  
  die;
   
 
  $a1=str_replace("master","noob?ts=master",$a1);
  
  if (@$_REQUEST["ts"] != "")
{

     $opts = ["http" => ["method" => "GET", "header" => $headers1]];

    $context = stream_context_create($opts);
    
    $haystack = file_get_contents($tsUrl.$_REQUEST["ts"], false, $context);
    echo $haystack;
}else{
    print $a1;
 }
?>